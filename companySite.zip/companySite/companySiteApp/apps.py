from django.apps import AppConfig


class CompanysiteappConfig(AppConfig):
    name = 'companySiteApp'
